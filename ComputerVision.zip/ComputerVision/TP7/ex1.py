# s = "The cities i like most in india are Mumbai, Bangalore, Dharamsala and Allahabad."
# s = s.lower()
# print(s)

words = ["indiA", "India", "india", "iNDia"]
words = [word.lower() for word in words]
print(words)